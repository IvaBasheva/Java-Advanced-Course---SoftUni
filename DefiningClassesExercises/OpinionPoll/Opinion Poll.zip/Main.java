package DefiningClassesExercises;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;

public class Main {
    public static void main(String[] args) {
        Scanner scanner =  new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());
        List <Person> personList = new ArrayList<>();

        for (int i = 1; i <= n; i++) {
            String [] personInformation = scanner.nextLine().split("\\s+");

            String name = personInformation[0];
            int age = Integer.parseInt(personInformation[1]);

            Person person = new Person(name, age);

            personList.add(person);
        }
        Predicate<Person> filterByAge = p -> p.getAge() > 30;

        personList.stream()
                .filter(filterByAge)
                .sorted((left, right) -> left.getName().compareTo(right.getName()))
                .forEach(p -> System.out.printf("%s - %d%n", p.getName(), p.getAge()));
    }
}
